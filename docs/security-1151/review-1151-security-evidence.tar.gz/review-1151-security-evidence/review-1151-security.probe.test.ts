import { eq } from 'drizzle-orm';
import { describe, expect, it } from 'vitest';
import { agents, assistants, companies, goals, people, tasks } from '../src/db/schema.js';
import { as, invitePerson, setUpCompany, testApp } from './helpers.js';

describe('review 1151 security counterexample', { timeout: 60000 }, () => {
  it('leaves another assistant hidden task out of goal progress', async () => {
    const { app, db } = await testApp();
    const ceo = await setUpCompany(app);
    const [company] = await db.select().from(companies);
    const companyId = company!.id;
    const oleg = await invitePerson(app, ceo, { name: 'Oleg', email: 'oleg@acme.com', access: { whole: true } });
    const [owner] = await db.select().from(people).where(eq(people.isOwner, true));
    const [goal] = await db.insert(goals).values({ companyId, number: 1, title: 'Company goal', responsiblePersonId: owner!.id }).returning();
    const [assistantPerson] = await db.insert(people).values({ companyId, name: 'Ava', status: 'active', isAgent: true, assistantOf: owner!.id, scopeKind: 'company' }).returning();
    const [assistantAgent] = await db.insert(agents).values({ companyId, kind: 'assistant', name: 'Ava', model: '' }).returning();
    await db.insert(assistants).values({ personId: assistantPerson!.id, companyId, program: 'avaclone', agentId: assistantAgent!.id });
    await db.insert(tasks).values({ companyId, number: 1, title: 'Private assistant work', goalId: goal!.id, assigneeAgentId: assistantAgent!.id, executorAgentId: assistantAgent!.id });

    const listed = await app.inject({ url: '/api/tasks?status=all', ...as(oleg) });
    expect(listed.statusCode).toBe(200);
    expect(listed.json().tasks).toEqual([]);
    const response = await app.inject({ url: '/api/goals', ...as(oleg) });
    expect(response.statusCode).toBe(200);
    expect(response.json().goals[0]).toMatchObject({ done: 0, total: 0, progress: null });
  });
});
