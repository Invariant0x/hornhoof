export async function freshPglite(): Promise<PGlite> {
  const runs = inject('initdbDataDir') as string | undefined;
  if (!initdb && runs) initdb = new Blob([readFileSync(runs)]);
  if (!initdb) {
    const first = new PGlite();
    /* A dump asked for before it is ready never comes. */
    await first.waitReady;
    initdb = await first.dumpDataDir('none');
    await first.close();
  }
  return withOwnParsers(new PGlite({ loadDataDir: initdb }));
}

export function ownDatabases(): void {
  ownEach = true;
}
