from pathlib import Path
import csv,json,re,statistics,hashlib,tarfile,subprocess,sys
candidate='3390423c6f86ae183987551b529520554f33168f'
base='359c2efaa27e9afb8842d0113dd5d6804aca467c'
root=Path('/data/work/agents/7d919e6e-ce7b-4904-9d67-955a51532502/hornhoof')
work=root.parent/'hornhoof-task-1177-evidence'
out=work/'docs'
proof=Path('/tmp/task-1177-proof-3390423c')
gates=Path('/tmp/task-1177-checks-3390423c')
before=Path('/tmp/task-1177-expanded-before')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==candidate
assert subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()==''
assert (proof/'source.txt').read_text().strip()==candidate
settings=json.loads((proof/'settings.json').read_text())
assert settings['watch']==False
assert len(settings['settings'])==1
assert settings['settings'][0]['testTimeout']==20000 and settings['settings'][0]['hookTimeout']==10000
before_sha=(before/'commit.txt').read_text().strip()
bd=json.loads((before/'tests.json').read_text())
bcases={r['title']:r for f in bd['testResults'] for r in f['assertionResults']}
assert len(bcases)==28 and bd['numFailedTests']==2
cases={name:[] for name in bcases}
runs=[]
preps=list(map(int,re.findall(r'keeper-peer database preparation: (\d+) ms',Path(str(proof)+'.log').read_text())))
assert len(preps)==21,(len(preps),preps)
all_load=[]
for i in range(21):
 p=proof/f'run-{i:02}'
 assert p.with_suffix('.status').read_text().strip()=='0'
 d=json.loads(p.with_suffix('.json').read_text())
 diag=json.loads(p.with_suffix('.diagnostic.json').read_text())
 assert diag['candidate']==candidate and not diag['errors']
 assert d['success'] and d['numTotalTests']==(74 if i==0 else 28)
 assert d['numFailedTests']==0 and d['numPendingTests']==0 and d['numTodoTests']==0
 assert len(d['testResults'])==(3 if i==0 else 1)
 assert all(f['state']=='passed' for f in diag['files'])
 assert all(f['status']=='passed' for f in d['testResults'])
 assert all(t['status']=='passed' for f in d['testResults'] for t in f['assertionResults'])
 if i==0:continue
 tests=[t for f in d['testResults'] for t in f['assertionResults']]
 assert {t['title'] for t in tests}==set(cases)
 for t in tests:cases[t['title']].append(t['duration'])
 samples=[]
 for suffix in ['.load.csv','.case-load.csv']:
  with p.with_suffix(suffix).open() as f:samples+=list(csv.DictReader(f))
 loads=[float(s['load1']) for s in samples]
 all_load+=loads
 times=[s['utc'] for s in samples]
 runs.append({'series':i,'source_sha':candidate,'passed':28,'failed':0,'file_duration_ms':round(diag['files'][0]['diagnostic']['duration'],3),'slowest_case_ms':round(max(t['duration'] for t in tests),3),'database_preparation_ms':preps[i],'load_1m_min':min(loads),'load_1m_max':max(loads),'load_5m_min':min(float(s['load5']) for s in samples),'load_5m_max':max(float(s['load5']) for s in samples),'load_15m_min':min(float(s['load15']) for s in samples),'load_15m_max':max(float(s['load15']) for s in samples),'first_sample_utc':min(times),'last_sample_utc':max(times)})
rows=[]
for name,ds in cases.items():
 assert len(ds)==20
 b=bcases[name]
 rows.append({'test':name,'before_ms':round(b['duration'],3),'before_status':b['status'],'after_min_ms':round(min(ds),3),'after_median_ms':round(statistics.median(ds),3),'after_max_ms':round(max(ds),3),'after_passed_series':20,'before_sha':before_sha,'after_sha':candidate})
def write_csv(path,rows):
 with path.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
write_csv(out/'task-1177-times.csv',rows)
write_csv(out/'task-1177-load.csv',runs)
for stem in ['task-1177-times','task-1177-load']:
 subprocess.run(['hh-xlsx',str(out/(stem+'.csv')),str(out/(stem+'.xlsx'))],check=True)
commands=[]
for name in ['protocol-build','build','types','lint']:
 receipt=json.loads((gates/(name+'.json')).read_text())
 assert receipt['candidate']==candidate and receipt['status']==0
 commands.append(f"- {' '.join(receipt['command'])}: exit 0, {receipt['seconds']:.3f} s. Full output: checks/{name}.log.")
file_times=[r['file_duration_ms'] for r in runs]
setup_times=preps[1:]
bl=[]
with (before/'load.csv').open() as f:bl=[float(r['load_1m']) for r in csv.DictReader(f)]
original=Path('/tmp/task-1177-before-full-file')
ol=[]
with (original/'load.csv').open() as f:
 for r in csv.DictReader(f):ol.append(float(r['load_1m']))
verification=f'''# Task 1177 verification

Status: DONE_WITH_CONCERNS. This is author verification of the named area, not the release's final suite.

Code candidate: {candidate}
Fresh integration base: {base}
Evidence branch: task-1177-evidence, parented at the exact code candidate. The hand-in records its resulting commit. Evidence files do not modify the checked code branch.

## Change and cause

All 28 keeper-peer scenarios use controlled time and explicit lease, network, report, sync, backup, slot and beat steps. Native socket/session completion no longer repeats unrelated keeper rounds and database reads. The existing worker clock and production keeper/app-call implementation were not changed. The recorded child fixture tests our start/input/exit handling without starting frpc. Real peer HTTP/TLS paths and database state remain exercised.

The four-second relay scenario still covers 727 virtual seconds, both outage windows and the original mode/word assertions. Every original keeper assertion is retained. The comparison fixture retains complete strict values. Test timeout 20 s and hook timeout 10 s are unchanged; no threshold was raised.

Cold embedded-database preparation runs at collection through the common prepareSharedDatabase entry point authorized by the head. The incoming base contributed the same method; the merge conflict was solely its comment. Each file runs in a fresh isolated fork. Named run 00 checks fixed-clock-fixture.test.ts, shared-test-database.test.ts and keeper-peer.test.ts; runs 01-20 check only keeper-peer.test.ts. Build and static checks completed before test execution.

## Before and after

The all-28 comparison baseline is {before_sha}: 26 passed, 2 timed out, file time 116367 ms, sampled 1-minute load {min(bl):.2f}-{max(bl):.2f}. Its first case includes cold setup (14142.425 ms); after timings exclude the separately reported collection preparation. The baseline already contains the first direct-step repair of the target relay-hiccup case. Its original earlier measurement was 12955 ms on 41d37dd3d4f919e63ed39f4f0ce0d898e440f4c5, with 28 passing cases in 48924 ms and sampled 1-minute load {min(ol):.2f}-{max(ol):.2f}; original log and load samples are in the archive. That first console log did not retain timings for all fast cases, so the table consistently uses the complete expanded baseline JSON.

Tables: task-1177-times.csv/.xlsx list every case's before duration/status and min/median/max across the 20 final runs, full source SHAs and pass counts. task-1177-load.csv/.xlsx list every run's file duration, slowest case, separately logged collection preparation, UTC samples and 1/5/15-minute load ranges. All durations are native runner diagnostics, not subtraction of the controlled application clock.

Final result: 20 consecutive keeper-peer runs x 28 = 560 passed; zero failed, skipped or unhandled errors. Run 00 also passed all 74 assertions across the three named files (console: 72 passed and 2 expected failures). Total final-candidate executions: 634. File duration min/median/max: {min(file_times):.3f} / {statistics.median(file_times):.3f} / {max(file_times):.3f} ms. Slowest individual final-series case: {max(r['slowest_case_ms'] for r in runs):.3f} ms. Recorded final-series 1-minute load: {min(all_load):.2f}-{max(all_load):.2f}. Database preparation min/median/max in the twenty runs: {min(setup_times)} / {statistics.median(setup_times):.1f} / {max(setup_times)} ms, outside scenario deadlines and disclosed separately. Run 00 keeper preparation: {preps[0]} ms. No parallel build or deliberately generated operating-system load. These are observed measurements, not a claim about benchmarked execution at every possible load.

## Executed commands on the final code candidate

{chr(10).join(commands)}
- NODE_OPTIONS=--max-old-space-size=6144 node --input-type=module - /tmp/task-1177-proof-3390423c < docs/task-1177-series.txt: exit 0. Run 00: three literal named files, 74 assertions. Runs 01-20: the literal keeper-peer.test.ts file, 28 assertions each. Exact selection, unchanged source, zero pending/errors, isolated forks and unchanged timeout settings checked on every run. Script is committed in the code candidate; full JSON, diagnostics and load data are in proof/.
- git diff --no-index -- /tmp/task-1177-functions-base.ts /tmp/task-1177-functions-candidate.ts: exit 0 with empty output (archived as functions/base.ts and functions/candidate.ts). Complete freshPglite and ownDatabases declarations were extracted from {base} and {candidate} and compared byte for byte. docs/task-1177-unchanged-functions.txt records their identical SHA256 digest.

An initial build after taking in the protocol changes failed because the local generated protocol declarations were stale. Rebuilding the protocol, then the server, resolved all errors without a source edit. Both failed and passing logs are preserved. Dependencies were already installed from the unchanged lockfile; no lockfile or manifest changes occurred in this merge.

## RED evidence and self-review

The expanded baseline records the two lease timeouts. An instrumented run at 3ffbc81aa13bf5f11aaac9df095780b44287a2ce plus its saved timing-only patch failed the final peer-door case after 21135.697 ms, with 15522.157 ms spent repeating network rounds while awaiting native completion. Direct readiness waits replaced those rounds. The profile source record contains the instrumentation patch and is not represented as an untouched-commit receipt.

A three-file run on 454318e56eebbc08d9becd09d6a57b0a7ef1a453 exposed a shared-database comparison-control allocation: 22712.939 ms total, 21818.704 ms setup. Immutable independent comparison values are now prepared at collection; assertions remain strict. The area run on 216a1d5e07c9cb8eb3ffc0eac3d73a0ab1506fa0 exposed a probe-close-bind port race (EADDRINUSE), followed by a collateral cold-database timeout. Fixture listeners now bind atomically to port 0, use the actual returned address and register cleanup before startup. The unavailable-app fixture keeps ownership of its address. No production listener changed. Raw failing results for these intermediate findings are retained.

Manual self-review checked unchanged assertions, exact virtual endpoint and outage windows, fixture clock guards/cache isolation, shared snapshot lifecycle, native cancellation, recorded child cleanup and real peer routes. Security inspection found test/measurement changes only: no production permission, secret-handling or deployment changes. No changed pure production function requires mutation testing. Turnkey work has no independent gate claim.

## Concerns

The expanded check:author is NOT GREEN: migrations.test.ts had 8 timeouts out of 41 at sampled 1-minute load 13.8-32.7. It calls only freshPglite and ownDatabases; their bodies are unchanged from the merge base, as the empty function diff shows. Full names, output and command: docs/task-1177-author-before.txt in the code candidate. The remaining selected caller files were not all executed; collection is not represented as execution. The head explicitly authorized closure against the three named files, twenty final-candidate keeper runs, build, types including tests and lint, and assigned migration timeouts to #1185. No limits were increased. No run_tests, local whole suite, main integration or release approval is claimed.

6a052242 без trailer, attestation в 3410fd97

The head accepted that DCO attestation on the task. Later commits are signed off; no history was rewritten. The task report records the observed fast-forward integration separately.
'''
(out/'task-1177-verification.md').write_text(verification)
archive=out/'task-1177-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for path,arc in [(proof,'proof'),(Path(str(proof)+'.log'),'proof.log'),(gates,'checks'),(before,'before-expanded'),(original,'before-original'),(Path('/tmp/task-1177-api-profile/run-04.json'),'red-network/run-04.json'),(Path('/tmp/task-1177-api-profile/source.txt'),'red-network/source.txt'),(Path('/tmp/task-1177-shared-control-red.json'),'red-shared-control.json'),(Path('/tmp/task-1177-proof-216a1d5e/run-00.json'),'red-port-race/run-00.json'),(Path('/tmp/task-1177-functions-base.ts'),'functions/base.ts'),(Path('/tmp/task-1177-functions-candidate.ts'),'functions/candidate.ts'),(Path(__file__),'make-evidence.py')]:
  tar.add(path,arcname=arc)
print(json.dumps({'candidate':candidate,'runs':20,'passed':560,'file_ms_min_median_max':[min(file_times),statistics.median(file_times),max(file_times)],'load1_min_max':[min(all_load),max(all_load)],'preparation_ms_min_median_max':[min(setup_times),statistics.median(setup_times),max(setup_times)],'archive_bytes':archive.stat().st_size},indent=2))
