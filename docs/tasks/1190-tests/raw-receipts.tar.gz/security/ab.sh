#!/bin/bash
# Alternates candidate and base runs of the two files that timed out; one log per run.
L="$1"; W=/data/work/agents/4728eaca-eddb-4da1-9242-71e29a5d4c7b
for round in 1 2; do
  for side in t1190 base1190; do
    for f in development-echelons-controls development-echelons-tools; do
      cd "$W/$side/apps/server" || exit 2
      start=$(date +%s); load=$(cut -d' ' -f1 /proc/loadavg)
      npx --no-install vitest run "test/$f.test.ts" --maxWorkers=1 --no-file-parallelism > "$L/ab-$round-$side-$f.log" 2>&1; rc=$?
      echo "round=$round side=$side head=$(git rev-parse --short HEAD) $f exit=$rc seconds=$(( $(date +%s) - start )) load_at_start=$load" >> "$L/ab.txt"
    done
  done
done
echo DONE >> "$L/ab.txt"
