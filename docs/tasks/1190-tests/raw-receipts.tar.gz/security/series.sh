#!/bin/bash
# Runs each named server test file alone, one after another; one log and exit code per file.
L="$1"; cd /data/work/agents/4728eaca-eddb-4da1-9242-71e29a5d4c7b/t1190/apps/server || exit 2
git rev-parse HEAD > "$L/head.txt"; git status --porcelain > "$L/dirty.txt"
for f in development-echelons-future-owners development-echelons-tools development-echelons-staff development-echelons-controls development-echelons-handoff development-echelons-wake agent-switch agents tasks-engine map-state wait-producers tasks-tools; do
  start=$(date +%s)
  npx --no-install vitest run "test/$f.test.ts" --maxWorkers=1 --no-file-parallelism > "$L/$f.log" 2>&1
  rc=$?
  echo "$f exit=$rc seconds=$(( $(date +%s) - start ))" >> "$L/summary.txt"
done
git rev-parse HEAD > "$L/head-after.txt"; git status --porcelain > "$L/dirty-after.txt"
echo DONE >> "$L/summary.txt"
