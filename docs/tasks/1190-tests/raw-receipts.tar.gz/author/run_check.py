import argparse,datetime,hashlib,json,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('label');p.add_argument('--cwd',default='.');

split=sys.argv.index('--');a=p.parse_args(sys.argv[1:split]);command=sys.argv[split+1:]
root=Path.cwd();evidence=root/'.task-1190-evidence';evidence.mkdir(exist_ok=True)
git=lambda *args:subprocess.check_output(['git',*args],cwd=root)
def snapshot():
 paths=set(git('diff','--name-only','HEAD','-z').decode().split('\0'))|set(git('ls-files','--others','--exclude-standard','-z').decode().split('\0'))
 files={path:hashlib.sha256((root/path).read_bytes()).hexdigest() if (root/path).is_file() else None for path in sorted(paths) if path and not path.startswith('.task-1190-evidence/')}
 return {'head':git('rev-parse','HEAD').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'dirtyFiles':files,'trackedPatchSha256':hashlib.sha256(git('diff','HEAD','--binary')).hexdigest()}
record={'command':command,'cwd':str((root/a.cwd).resolve()),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'start':snapshot()}
(evidence/(a.label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
with (evidence/(a.label+'.log')).open('w') as f:
 f.write('$ '+' '.join(command)+'\n');f.flush()
 result=subprocess.run(command,cwd=root/a.cwd,stdout=f,stderr=subprocess.STDOUT)
record.update(exitCode=result.returncode,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),end=snapshot())
record['sourceUnchangedDuringRun']=record['start']==record['end']
record['logSha256']=hashlib.sha256((evidence/(a.label+'.log')).read_bytes()).hexdigest()
(evidence/(a.label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print((evidence/(a.label+'.log')).read_text())
print(json.dumps({'record':a.label+'.json','exitCode':result.returncode,'sourceUnchangedDuringRun':record['sourceUnchangedDuringRun']}))
sys.exit(result.returncode if record['sourceUnchangedDuringRun'] else 3)
