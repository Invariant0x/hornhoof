# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: agent-history.spec.ts >> employee history in en, light, at 375px
- Location: e2e/agent-history.spec.ts:50:7

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: false
Received: true
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - banner:
    - navigation "Sections" [ref=e4]:
      - button "Map" [ref=e5] [cursor=pointer]
      - button "Tasks" [ref=e6] [cursor=pointer]
      - button "People" [ref=e7] [cursor=pointer]
      - button "Subscriptions & API" [ref=e8] [cursor=pointer]
      - button "Machines" [ref=e9] [cursor=pointer]
    - button "Account" [ref=e12] [cursor=pointer]: I
  - main [ref=e13]:
    - generic [ref=e14]:
      - generic [ref=e15]:
        - img [aria-hidden]:
          - generic [ref=e16] [cursor=pointer]
        - button "Open the orchestrator" [ref=e17] [cursor=pointer]:
          - generic "agents working" [ref=e25]: 0/1
        - 'button "Development 0/1 DEV free: 1" [ref=e26] [cursor=pointer]':
          - generic [ref=e28]:
            - generic [ref=e29]:
              - generic [ref=e30]: Development
              - generic "Agents at work out of all" [ref=e31]: 0/1
            - generic [ref=e32]: DEV
            - 'img "free: 1" [ref=e34]'
        - button "Move Orchestrator" [ref=e36]
        - button "Move Development" [ref=e37]
      - generic [ref=e38]:
        - button "Zoom out" [ref=e39] [cursor=pointer]
        - generic [ref=e41]: 100%
        - button "Zoom in" [ref=e42] [cursor=pointer]
        - button "Show everything" [ref=e45] [cursor=pointer]
    - generic [ref=e48]:
      - region "Department schema" [ref=e49]:
        - generic [ref=e50]:
          - region "Members":
            - heading "Members" [level=3] [ref=e51]
            - group "Others" [ref=e52]:
              - generic [ref=e55]:
                - generic [ref=e56]: Others
                - generic [ref=e57]: 1 agent
              - generic [ref=e58]:
                - button "Bruno Codex free Default, default effort, Codex Waiting for a new task" [pressed] [ref=e59] [cursor=pointer]:
                  - generic [ref=e61]:
                    - generic [ref=e62]:
                      - generic [ref=e67]: Bruno
                      - img "Codex" [ref=e68]
                      - generic "free" [ref=e71]
                    - generic [ref=e72]: Default, default effort, Codex
                    - generic [ref=e73]: Waiting for a new task
                - checkbox "Bruno is on" [checked] [ref=e74] [cursor=pointer]
          - region "Head":
            - heading "Head" [level=3] [ref=e75]
            - generic [ref=e78]:
              - generic [ref=e79]: DEV, Development
              - generic [ref=e85]: No head yet.
              - generic [ref=e86]: 0 of 1 agent working, 0 roles
      - navigation "Development" [ref=e87]:
        - button "Back to the map" [ref=e88] [cursor=pointer]
        - generic [ref=e91]:
          - heading "Development" [level=2] [ref=e92]
          - generic [ref=e93]: DEV
      - generic [ref=e94]:
        - button "Tree" [ref=e95] [cursor=pointer]
        - button "Speed" [ref=e100] [cursor=pointer]
        - button "Department tasks" [ref=e105] [cursor=pointer]
        - button "About the department" [ref=e106] [cursor=pointer]
        - button "+ Hire" [ref=e107] [cursor=pointer]
      - generic [ref=e108]:
        - button "Zoom out" [ref=e109] [cursor=pointer]
        - generic [ref=e111]: 62%
        - button "Zoom in" [ref=e112] [cursor=pointer]
        - button "Show everything" [ref=e115] [cursor=pointer]
  - complementary "Bruno" [ref=e118]:
    - generic [ref=e119]:
      - generic [ref=e120]:
        - button "Close" [ref=e121] [cursor=pointer]
        - button "Minimize" [ref=e124] [cursor=pointer]
        - button "Full screen" [ref=e126] [cursor=pointer]
      - generic [ref=e129]: Bruno
      - button "Back to conversation" [ref=e130] [cursor=pointer]
      - button "Terminal" [ref=e133] [cursor=pointer]
      - 'button "Inbox: all read" [ref=e136] [cursor=pointer]'
      - button "Card" [expanded] [active] [ref=e139] [cursor=pointer]
      - button "No task" [disabled] [ref=e142]: Task
    - 'complementary "Card: Bruno" [ref=e146]':
      - generic [ref=e147]:
        - generic [ref=e152]: Bruno
        - button "Close" [ref=e153] [cursor=pointer]
      - generic [ref=e156]:
        - generic [ref=e157]:
          - heading "Bruno" [level=3] [ref=e158]
          - paragraph [ref=e159]: Development
          - paragraph [ref=e160]:
            - text: Sleeping
            - generic "waiting for a task" [ref=e162]
        - paragraph [ref=e163]: Only people with access to this employee's department or the whole company can change it.
        - generic [ref=e164]:
          - generic [ref=e165]:
            - generic [ref=e166]: Runs on
            - combobox "Runs on" [disabled] [ref=e167]:
              - option "None yet" [selected]
          - generic [ref=e168]:
            - generic [ref=e169]: Model
            - combobox "Model" [disabled] [ref=e170]:
              - option "Default" [selected]
          - generic [ref=e171]:
            - generic [ref=e172]: Effort
            - combobox "Effort" [disabled] [ref=e173]:
              - option "Default" [selected]
        - region [ref=e174]:
          - heading "Timer" [level=4] [ref=e175]
          - paragraph [ref=e176]: The employee wakes on its own every so often, outside any task, and does what you write here.
          - generic [ref=e177] [cursor=pointer]:
            - checkbox "Wake on a timer" [disabled] [ref=e178]
            - generic [ref=e179]: Wake on a timer
        - region [ref=e180]:
          - heading "Skills" [level=4] [ref=e181]
        - region [ref=e182]:
          - generic [ref=e183]:
            - heading "Prompt" [level=4] [ref=e184]
            - generic [ref=e185]:
              - button "By skill" [pressed] [ref=e186] [cursor=pointer]
              - button "Raw" [ref=e187] [cursor=pointer]
          - paragraph [ref=e188]: "Instructions: 0 characters of 200,000. Every turn sends all of them to the program."
        - region [ref=e189]:
          - heading "Changes" [level=4] [ref=e190]
          - list [ref=e191]:
            - listitem [ref=e192]: "Name: Head Hana-long-head-name-long-head-name-long-head-name-long-head-name-long-head-name-long-head-name-long-head-name-long-head-name-long-head-name-long-head-name-long-head-name-long-head-name- (authority: Dana-long-owner-name-long-owner-name-long-owner-name-long-owner-name-long-owner-name-long-owner-name-long-owner-name-long-owner-name-long-owner-name-long-owner-name-long-owner-name-long-owner-name-), 30/10/2026, 09:00"
            - listitem [ref=e193]: "Skills: Ivan, 30/10/2026, 09:00"
            - listitem [ref=e194]: "Switched on or off: Orchestrator, 30/10/2026, 09:00"
            - listitem [ref=e195]: Reset to the template, 30/10/2026, 09:00
```

# Test source

```ts
  1   | import { writeFile } from 'node:fs/promises';
  2   | import { expect, test } from '@playwright/test';
  3   | import { LANGUAGES, type Language, type Messages } from '../src/i18n';
  4   | import type { AgentCardView, Employee, Org } from '../src/types';
  5   | import { ME, serveApi } from './api';
  6   | 
  7   | const HEAD = `Hana-${'long-head-name-'.repeat(12)}`;
  8   | const PERSON = `Dana-${'long-owner-name-'.repeat(12)}`;
  9   | const AT = '2026-10-30T09:00:00.000Z';
  10  | const WORKER: Employee = {
  11  |   id: 'b1', name: 'Bruno', roleId: 'DEV-ENG', title: { en: 'Engineer', ru: 'Инженер' }, kind: 'worker', model: '', modelName: null,
  12  |   provider: 'codex', effort: null, state: 'sleeping', status: 'idle', on: true, timer: null, task: null,
  13  |   context: null, program: null, alarm: null, retry: null, failure: null,
  14  | };
  15  | const ORG: Org = {
  16  |   company: ME.company, orchestrator: null, agents: { total: 1, working: 0 }, people: [],
  17  |   departments: [{ id: 'd2', name: 'Development', templateKey: null, roleCode: 'DEV', about: '', agents: { total: 1, working: 0 },
  18  |     products: [], teams: [], people: [], employees: [WORKER], roles: [] }],
  19  | };
  20  | const CARD: AgentCardView = {
  21  |   id: WORKER.id, name: WORKER.name, kind: 'worker', role: null, department: { id: 'd2', name: 'Development' },
  22  |   currentTask: null, product: null, team: null, teams: [], model: '', effort: null, subscription: null, machine: null,
  23  |   state: 'sleeping', program: null, alarm: null, retry: null, failure: null, skills: [], parts: [], raw: '',
  24  |   instructions: { length: 0, max: 200_000 }, runsOn: [], interrupted: [], canEdit: false, canRemove: false, timer: null,
  25  |   changes: [
  26  |     { field: 'name', personName: PERSON, actingAgent: { id: 'removed-head', name: HEAD }, byOrchestrator: false, at: AT },
  27  |     { field: 'skills', personName: 'Ivan', actingAgent: null, byOrchestrator: false, at: AT },
  28  |     { field: 'switch', personName: null, actingAgent: null, byOrchestrator: true, at: AT },
  29  |     { field: 'reset', personName: null, actingAgent: null, byOrchestrator: false, at: AT },
  30  |   ],
  31  | };
  32  | 
  33  | async function wordsFor(locale: Language): Promise<Messages> {
  34  |   return (await import(`../src/i18n/${locale}.ts`) as Record<string, Messages>)[locale]!;
  35  | }
  36  | 
  37  | /* Rank the actual history sentences of every shipped locale, so adding a language changes this check's matrix. */
  38  | const ranking = await Promise.all(LANGUAGES.map(async ({ id }) => {
  39  |   const t = await wordsFor(id);
  40  |   const strings = [t.agent.history, ...CARD.changes.map(c => t.agent.changed(t.agent.fields[c.field]!, c.actingAgent ? t.agent.byHead(c.actingAgent.name, c.personName) : c.byOrchestrator ? t.agent.byOrchestrator : c.personName, AT))];
  41  |   return { id, characters: strings.join('').length };
  42  | }));
  43  | ranking.sort((a, b) => a.characters - b.characters || a.id.localeCompare(b.id));
  44  | const rtl = LANGUAGES.find(({ id }) => /^(ar|he|fa|ur)(-|$)/.test(id));
  45  | const locales = [...new Set([ranking[0]!.id, ranking.at(-1)!.id, ...(rtl ? [rtl.id] : [])])];
  46  | 
  47  | for (const locale of locales) {
  48  |   for (const theme of ['light', 'cyberpunk']) {
  49  |     for (const width of [375, 1280]) {
  50  |       test(`employee history in ${locale}, ${theme}, at ${width}px`, async ({ page }, info) => {
  51  |         const t = await wordsFor(locale);
  52  |         const errors: string[] = [];
  53  |         page.on('pageerror', error => errors.push(error.message));
  54  |         page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
  55  |         page.on('response', response => { if (response.status() >= 400) errors.push(`${response.status()} ${new URL(response.url()).pathname}`); });
  56  |         await page.setViewportSize({ width, height: 900 });
  57  |         await page.clock.install({ time: new Date('2026-11-17T08:00:00.000Z') });
  58  |         await page.addInitScript(({ locale, theme }) => {
  59  |           localStorage.setItem('hh-lang', locale);
  60  |           localStorage.setItem('hh-theme', theme);
  61  |         }, { locale, theme });
  62  |         await serveApi(page);
  63  |         const routes: Record<string, unknown> = {
  64  |           '/api/org': ORG,
  65  |           '/api/tasks?status=open&department=d2': { tasks: [] },
  66  |           '/api/agents/b1': CARD,
  67  |           '/api/agents/b1/events?last=300': { events: [], state: { ready: true, reason: null, busy: false, runningJobId: null, queued: 0, terminal: false } },
  68  |         };
  69  |         await page.route('**/api/**', route => {
  70  |           const url = new URL(route.request().url());
  71  |           const path = url.pathname + url.search;
  72  |           return path in routes ? route.fulfill({ json: routes[path] }) : route.fallback();
  73  |         });
  74  |         await page.goto('/departments/d2');
  75  |         await page.getByRole('region', { name: t.dept.members, exact: true }).getByRole('button', { name: /Bruno/ }).click();
  76  |         await page.getByRole('button', { name: t.window.card, exact: true }).click();
  77  |         const card = page.getByRole('complementary', { name: t.window.cardOf('Bruno'), exact: true });
  78  |         const history = card.locator('section.ac-history').filter({ has: page.getByRole('heading', { name: t.agent.history, exact: true }) });
  79  |         await history.scrollIntoViewIfNeeded();
  80  |         await page.evaluate(() => document.fonts.ready);
  81  |         const lines = history.getByRole('listitem');
  82  |         await expect(lines).toHaveCount(4);
  83  |         await expect(lines.nth(0)).toContainText(t.agent.byHead(HEAD, PERSON));
  84  |         await expect(lines.nth(1)).toContainText('Ivan');
  85  |         await expect(lines.nth(2)).toContainText(t.agent.byOrchestrator);
  86  |         await expect(lines.nth(3)).not.toContainText(PERSON);
  87  |         const fits = () => history.evaluate(root => [...root.querySelectorAll('li')].every(li => li.scrollWidth <= li.clientWidth));
  88  |         expect(await fits()).toBe(true);
  89  |         /* Prove the geometry assertion detects the long actor being clipped or overflowing. */
  90  |         await lines.nth(0).evaluate(li => { li.style.whiteSpace = 'nowrap'; });
> 91  |         expect(await fits()).toBe(false);
      |                              ^ Error: expect(received).toBe(expected) // Object.is equality
  92  |         await lines.nth(0).evaluate(li => { li.style.removeProperty('white-space'); });
  93  |         expect(await fits()).toBe(true);
  94  |         const geometry = await history.evaluate(root => {
  95  |           const body = root.closest('.ac-body')!;
  96  |           const list = root.querySelector('ul')!;
  97  |           return { width: root.getBoundingClientRect().width, height: root.getBoundingClientRect().height,
  98  |             clientWidth: body.clientWidth, scrollWidth: body.scrollWidth, color: getComputedStyle(list).color,
  99  |             font: getComputedStyle(list).fontFamily, gap: getComputedStyle(list).gap,
  100 |             token: getComputedStyle(root).getPropertyValue('--muted').trim() };
  101 |         });
  102 |         expect(geometry.scrollWidth).toBeLessThanOrEqual(geometry.clientWidth);
  103 |         expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  104 |         const look = `${locale}-${theme}-${width}`;
  105 |         await writeFile(info.outputPath('sizes.json'), JSON.stringify([{ browser: info.project.name, look, screen: 'employee-history', sizes: { width: geometry.width, height: geometry.height } }]));
  106 |         await info.attach('geometry', { body: JSON.stringify({ geometry, ranking, rtl: rtl?.id ?? 'NOT_AVAILABLE' }), contentType: 'application/json' });
  107 |         await page.screenshot({ path: info.outputPath(`${look}.png`), animations: 'disabled' });
  108 |         expect(errors).toEqual([]);
  109 |       });
  110 |     }
  111 |   }
  112 | }
  113 | 
```