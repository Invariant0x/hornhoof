import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { complexityAt } from '../scripts/author-check/wired.mjs';
import { grownFunctions, parseHunks } from '../scripts/author-check/plan.mjs';
import { parseCrapEdn, judgeFunctions, worstCrap, parseLcov, changedLines } from '../scripts/author-check/judge.mjs';
const commit = 'b0b972aa75fbfa31a6f0b0decf500858ea68278a';
const base = '76c4b7d571aba37c5eefd12cac4eeee4945c01e5';
const evidence = '.task-1220-evidence';
const git = args => execFileSync('git', args, { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 });
const groups = [
  { name: 'server', root: 'apps/server', files: ['src/auth/session.ts','src/db/schema.ts','src/modules/agents/routes.ts','src/modules/assistants/setup.ts','src/modules/departments/hire.ts','src/modules/departments/routes.ts','src/modules/people/routes.ts','src/modules/telegram/routes.ts'] },
  { name: 'web', root: 'apps/web', files: ['src/types.ts','src/ui/AgentCard.tsx','src/i18n/en.ts','src/i18n/ru.ts'] },
];
const all = [], coverage = {};
for (const group of groups) {
  const entries = parseCrapEdn(readFileSync(`${evidence}/crapper-${group.name}.edn`, 'utf8'));
  const before = complexityAt(git)(group.root, base, group.files.map(path => ({ path, from: `${group.root}/${path}` })));
  writeFileSync(`${evidence}/base-complexity-${group.name}.json`, JSON.stringify(before, null, 2));
  const judged = judgeFunctions(entries, grownFunctions(entries, before));
  all.push(...judged.map(entry => ({ ...entry, project: group.name })));
  for (const [file, hits] of Object.entries(parseLcov(readFileSync(`${evidence}/${group.name}-coverage/lcov.info`, 'utf8')))) coverage[`${group.root}/${file}`] = hits;
}
const hunks = parseHunks(git(['diff', '-U0', '--no-color', base, commit]));
const sourcePaths = groups.flatMap(group => group.files.map(file => `${group.root}/${file}`));
const result = { commit, base, sources: sourcePaths, functions: all.length, fails: all.filter(entry => entry.verdict === 'fails'), unknown: all.filter(entry => entry.verdict === 'unknown'), touched: all.filter(entry => entry.verdict === 'touched'), worstCrap: worstCrap(all), changedLines: changedLines(hunks, coverage, sourcePaths), newHelpers: all.filter(entry => ['employeeChangedBy', 'changeAuthor'].includes(entry.name)), judged: all };
writeFileSync(`${evidence}/quality-comparison.json`, JSON.stringify(result, null, 2)+'\n');
console.log(JSON.stringify({ ...result, judged: undefined, touched: result.touched.map(({ name, namespace, complexity, crap }) => ({ name, namespace, complexity, crap })) }, null, 2));
process.exitCode = result.fails.length || result.unknown.length ? 1 : 0;
