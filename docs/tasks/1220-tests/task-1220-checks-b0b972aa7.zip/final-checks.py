from pathlib import Path
import subprocess, shutil, json, sys
root=Path.cwd()
evidence=root/'.task-1220-evidence'
server=['src/auth/session.ts','src/db/schema.ts','src/modules/agents/routes.ts','src/modules/assistants/setup.ts','src/modules/departments/hire.ts','src/modules/departments/routes.ts','src/modules/people/routes.ts','src/modules/telegram/routes.ts']
web=['src/types.ts','src/ui/AgentCard.tsx','src/i18n/en.ts','src/i18n/ru.ts']
lint=['apps/server/'+s for s in server]+['apps/server/test/head-department-control.test.ts','apps/server/test/agents.test.ts','apps/server/test/agent-changes-migration.test.ts']+['apps/web/'+s for s in web]+['apps/web/test/AgentCard.test.tsx','apps/web/test/api-mock.ts','apps/web/e2e/agent-history.spec.ts','apps/web/e2e/agent-history.config.ts']
steps=[
 ('server-types-final',['npx','--no-install','tsc','-p','apps/server/tsconfig.json','--noEmit'],root,None),
 ('server-test-types-final',['npx','--no-install','tsc','-p','apps/server/tsconfig.eslint.json','--noEmit'],root,None),
 ('web-types-final',['npx','--no-install','tsc','-p','apps/web/tsconfig.json','--noEmit'],root,None),
 ('server-build',['npm','run','build','-w','@hornhoof/server'],root,None),
 ('web-build',['npm','run','build','-w','@hornhoof/web'],root,None),
 ('lint-final',['npx','--no-install','eslint',*lint],root,None),
 ('crapper-server',['crapper','--coverage-report',str(evidence/'server-coverage/lcov.info'),*server],root/'apps/server', '.metrics/crap.edn'),
 ('crapper-web',['crapper','--coverage-report',str(evidence/'web-coverage/lcov.info'),*web],root/'apps/web', '.metrics/crap.edn'),
 ('dryer',['dryer','--threshold','0.8',*lint],root,'.metrics/dry.edn'),
]
results=[]
for name,args,cwd,artifact in steps:
 log=evidence/(name+'.log')
 with log.open('w') as out:
  out.write('$ '+' '.join(args)+'\n'); out.flush()
  process=subprocess.run(args,cwd=cwd,stdout=out,stderr=subprocess.STDOUT)
 result={'name':name,'command':args,'cwd':str(cwd.relative_to(root)),'exitCode':process.returncode}
 results.append(result)
 (evidence/'final-check-statuses.json').write_text(json.dumps({'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'results':results},indent=2)+'\n')
 print(name, 'exit', process.returncode, 'log',log.name,flush=True)
 if artifact and (cwd/artifact).exists(): shutil.copyfile(cwd/artifact,evidence/(name+'.edn'))
 if process.returncode:
  print(log.read_text(),flush=True); sys.exit(process.returncode)
