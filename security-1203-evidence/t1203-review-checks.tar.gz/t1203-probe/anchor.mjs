// Probe of our own leader script: after a managed command ends and the wrapper disconnects, is the anchor alive?
import { spawn } from 'node:child_process';
import { readFileSync } from 'node:fs';
const src = readFileSync(process.argv[2], 'utf8');
const PARKED = src.slice(src.indexOf('String.raw`') + 11, src.indexOf('`;', src.indexOf('PARKED_CHECK')));
const leader = spawn(process.execPath, ['-e', PARKED], { stdio: ['ignore', 'inherit', 'inherit', 'ipc'], detached: true });
await new Promise(r => leader.once('spawn', r));
const alive = pid => { try { process.kill(pid, 0); return true; } catch { return false; } };
const groupOf = pid => { try { const t = readFileSync(`/proc/${pid}/stat`, 'utf8'); return t.slice(t.lastIndexOf(')') + 2).split(' ')[2]; } catch { return null; } };
leader.send({ command: ['sh', '-c', 'sleep 3 & echo $! > ' + process.argv[3] + '; exit 0'], env: process.env, managed: true });
const result = await new Promise(r => leader.once('message', r));
leader.disconnect(); leader.unref();
await new Promise(r => setTimeout(r, 400));
const left = Number(readFileSync(process.argv[3], 'utf8'));
console.log(JSON.stringify({ result, leaderAlive: alive(leader.pid) && groupOf(leader.pid) !== null, leaderState: (() => { try { return readFileSync(`/proc/${leader.pid}/stat`, 'utf8').split(') ')[1][0]; } catch { return 'gone'; } })(), leftoverAlive: alive(left), leftoverGroup: groupOf(left), leaderGroup: String(leader.pid) }));
try { process.kill(-leader.pid, 'SIGKILL'); } catch {}
process.exit(0);
